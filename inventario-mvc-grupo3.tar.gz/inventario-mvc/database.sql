-- ============================================================
-- Sistema de Control de Inventario y Rentabilidad
-- Script de creación de base de datos (SQLite compatible)
-- Grupo 3: Jesus Gonzalez, Marlon Gelvez, Sebastian Velandia
-- ============================================================

CREATE TABLE IF NOT EXISTS categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE,
    descripcion TEXT,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    descripcion TEXT,
    categoria_id INTEGER,
    costo REAL NOT NULL DEFAULT 0,
    precio_venta REAL NOT NULL DEFAULT 0,
    stock INTEGER NOT NULL DEFAULT 0,
    stock_minimo INTEGER NOT NULL DEFAULT 5,
    activo INTEGER NOT NULL DEFAULT 1,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    documento TEXT UNIQUE,
    telefono TEXT,
    email TEXT,
    direccion TEXT,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero_factura TEXT NOT NULL UNIQUE,
    cliente_id INTEGER,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    subtotal REAL NOT NULL DEFAULT 0,
    descuento REAL NOT NULL DEFAULT 0,
    total REAL NOT NULL DEFAULT 0,
    estado TEXT NOT NULL DEFAULT 'despachado',
    notas TEXT,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS items_pedido (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pedido_id INTEGER NOT NULL,
    producto_id INTEGER NOT NULL,
    cantidad INTEGER NOT NULL,
    precio_unitario REAL NOT NULL,
    costo_unitario REAL NOT NULL,
    subtotal REAL NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

CREATE TABLE IF NOT EXISTS entradas_inventario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER NOT NULL,
    cantidad INTEGER NOT NULL,
    costo_unitario REAL NOT NULL,
    proveedor TEXT,
    notas TEXT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- Datos iniciales de categorías
INSERT OR IGNORE INTO categorias (nombre, descripcion) VALUES
    ('General', 'Categoría general'),
    ('Bisutería', 'Accesorios y joyería'),
    ('Electrónica', 'Dispositivos electrónicos'),
    ('Ropa', 'Prendas de vestir'),
    ('Hogar', 'Artículos para el hogar');

-- Datos de ejemplo
INSERT OR IGNORE INTO clientes (nombre, documento, telefono) VALUES
    ('Cliente General', '000000000', '0000000000'),
    ('María García', '12345678', '3001234567'),
    ('Carlos López', '87654321', '3109876543');

INSERT OR IGNORE INTO productos (codigo, nombre, categoria_id, costo, precio_venta, stock, stock_minimo) VALUES
    ('P001', 'Collar Dorado', 2, 5000, 12000, 20, 5),
    ('P002', 'Aretes Plateados', 2, 3000, 8000, 15, 5),
    ('P003', 'Pulsera Cristal', 2, 4000, 10000, 10, 3),
    ('P004', 'Anillo Ajustable', 2, 2000, 6000, 25, 5),
    ('P005', 'Cadena Fina', 2, 6000, 15000, 8, 3);
