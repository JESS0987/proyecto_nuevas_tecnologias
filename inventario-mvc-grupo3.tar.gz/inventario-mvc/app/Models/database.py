"""
Model: Conexión a la base de datos SQLite
"""

import sqlite3
import os
from config.settings import DATABASE_PATH, DATABASE_SQL


class Database:
    _instance = None

    @classmethod
    def get_connection(cls):
        """Retorna una conexión a la base de datos."""
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row          # acceso por nombre de columna
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    @classmethod
    def initialize(cls):
        """Crea las tablas si no existen, usando el script SQL."""
        if not os.path.exists(DATABASE_PATH):
            with cls.get_connection() as conn:
                with open(DATABASE_SQL, "r", encoding="utf-8") as f:
                    conn.executescript(f.read())
            print("[DB] Base de datos inicializada.")
        else:
            # Asegura que las tablas existan aunque el archivo ya exista
            with cls.get_connection() as conn:
                with open(DATABASE_SQL, "r", encoding="utf-8") as f:
                    conn.executescript(f.read())
